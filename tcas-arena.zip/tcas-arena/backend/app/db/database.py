from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from app.config import settings

# check_same_thread=False จำเป็นสำหรับ SQLite เมื่อใช้กับ FastAPI (multi-thread)
connect_args = {"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(settings.DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """Dependency สำหรับ inject DB session เข้า router"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
